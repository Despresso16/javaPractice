public class Okrag {
    public double promien;
    public Punkt srodek;
    public Okrag(){
        this.promien = 0;
        this.srodek = new Punkt(0, 0);
    }
    public Okrag(double promien, double przesunX, double przesunY){
        this.promien = promien;
        this.srodek = new Punkt(przesunX, przesunY);
    }
    public double obliczPole(){
        return Math.PI * Math.pow(promien, 2);
    }
    public double obliczObwod(){
        return  2 * Math.PI * promien;
    }
    public boolean zawiera(Punkt pkt){
        if(pkt.x >= this.srodek.x + (-1 * this.promien) && pkt.x <= this.srodek.x + this.promien && pkt.y >= this.srodek.y + (-1 * this.promien) && pkt.y <= this.srodek.y + this.promien ) return true;
        else return false;
    }
    public boolean przecina(Okrag okr){
        double odlegloscSrodkow = Math.pow(this.srodek.x - okr.srodek.x, 2) + Math.pow(this.srodek.y - okr.srodek.y, 2);
        double promienieMinus = this.promien - okr.promien;
        if (promienieMinus < 0) promienieMinus *= -1;
        if(promienieMinus < odlegloscSrodkow && odlegloscSrodkow < this.promien + okr.promien) return true;
        else return false;
    }
}
