class Prostokat
{
   double dlugosc;
   double szerokosc;
   Punkt srodek;
   Prostokat()            
   {                      
      this.dlugosc=0.0;   
      this.szerokosc=0.0;
      this.srodek = new Punkt(0, 0);
   }                      
 
   Prostokat(double dlugosc,double szerokosc)  
   {                                          
      this.dlugosc=dlugosc;                   
      this.szerokosc=szerokosc;
      this.srodek = new Punkt(szerokosc / 2, dlugosc / 2);
   }
   Prostokat(double dlugosc,double szerokosc, double przesunX, double przesunY)
   {
      this.dlugosc=dlugosc;
      this.szerokosc=szerokosc;
      this.srodek = new Punkt( przesunX + szerokosc / 2, przesunY + dlugosc / 2);
   }

   double pole()                
   {                            
      return dlugosc*szerokosc; 
   }
   public double obwod(){
      return 2 * dlugosc + 2 * szerokosc;
   }
   public void przesun(double u,double v){
      this.srodek.przesun(u, v);
   }
   public boolean zawiera(Punkt pkt){
      if(pkt.x >= this.srodek.x + (-1 * this.szerokosc / 2) && pkt.x <= this.srodek.x + (this.szerokosc / 2) && pkt.y >= this.srodek.y + (-1 * this.dlugosc / 2) && pkt.y <= this.srodek.x + (this.dlugosc / 2)) return  true;
      else return false;
   }
   public boolean przecina(Okrag okr) {
      double xMin = this.srodek.x - this.szerokosc / 2;
      double xMax = this.srodek.x + this.szerokosc / 2;
      double yMin = this.srodek.y - this.dlugosc / 2;
      double yMax = this.srodek.y + this.dlugosc / 2;
      double najlbizszyX = Math.max(xMin, Math.min(okr.srodek.x, xMax));
      double najlblizszyY = Math.max(yMin, Math.min(okr.srodek.y, yMax));
      double dystans = Math.pow(okr.srodek.x - najlbizszyX, 2) + Math.pow(okr.srodek.y - najlblizszyY, 2);
      if(dystans <= Math.pow(okr.promien, 2)) return true;
      else return false;
   }
}