public class Main
{
   public static void main(String[] args)         
   {                                             
      Prostokat obj;                             
      obj=new Prostokat(3,4, 1, 1);
      double x=obj.pole();                       
 
      System.out.println("Pole prostokata: "+x);
      System.out.println("Obwod " + obj.obwod());
      Punkt punkt = new Punkt(3, 3);
      System.out.println("Zad 4");
      System.out.println(obj.srodek.toString());
      obj.przesun(3, 5);
      System.out.println(obj.srodek.toString());
      System.out.println("Zad 5");
      Okrag okrag = new Okrag(10, 1, 1);
      System.out.println(okrag.obliczObwod());
      System.out.println(okrag.obliczPole());
      System.out.println("Zad 6");
      System.out.println(obj.srodek.toString());
      System.out.println(obj.szerokosc / 2 + " , " + obj.dlugosc /2 );
      System.out.println(obj.zawiera(new Punkt(5, 7)));
      System.out.println(obj.zawiera(new Punkt(3.3, 9)));
      System.out.println(obj.zawiera(new Punkt(33.3, 7)));
      System.out.println(obj.zawiera(new Punkt(0, 0)));
      System.out.println(obj.zawiera(new Punkt(6, 7.5)));
      System.out.println("Zad 7");
      System.out.println(okrag.srodek.toString() + ", " + okrag.promien);
      System.out.println(okrag.przecina(new Okrag(11, 1, 3)));
      System.out.println(okrag.przecina(new Okrag(31, 1, 3)));
      System.out.println(okrag.przecina(new Okrag(11, 4, 3)));
      System.out.println("Zad 8");

      System.out.println(obj.przecina(new Okrag(11, 1, 3)));
      System.out.println(obj.przecina(new Okrag(3, 2, 2)));
      System.out.println(obj.przecina(new Okrag(1, 12, 12)));
      System.out.println(obj.przecina(new Okrag(6, 0, 0)));
      System.out.println();
      System.out.println(new Prostokat(10, 5, 0, 0).przecina(new Okrag(11, 1, 3)));
      System.out.println(new Prostokat(10, 5, 0, 0).przecina(new Okrag(3, 2, 2)));
      System.out.println(new Prostokat(10, 5, 0, 0).przecina(new Okrag(1, 12, 12)));
      System.out.println(new Prostokat(10, 5, 0, 0).przecina(new Okrag(6, 0, 0)));

   }                                             
}