import java.math.BigDecimal;
import java.math.BigInteger;

public class BigLiczba {
    private BigInteger wartosc;

    public BigLiczba(BigInteger wartosc) {
        this.wartosc = wartosc;
    }

    public BigInteger getWartosc() {
        return wartosc;
    }

    public void setWartosc(BigInteger wartosc) {
        this.wartosc = wartosc;
    }
    public boolean isDividedBy(BigInteger num){
        return this.wartosc.mod(num).equals(0);
    }
    public boolean isPrimeNumber(){
        return this.wartosc.isProbablePrime(0);
    }
}
