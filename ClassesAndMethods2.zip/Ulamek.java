public class Ulamek {
    private int licznik;
    private  int mianownik;

    public Ulamek(int licznik, int mianownik) {
        this.licznik = licznik;
        this.mianownik = mianownik;
    }


    public int getLicznik() {
        return licznik;
    }

    public void setLicznik(int licznik) {
        this.licznik = licznik;
    }

    public int getMianownik() {
        return mianownik;
    }

    public void setMianownik(int mianownik) {
        this.mianownik = mianownik;
    }
    public double rozwDziesietne(){
        return (double) this.licznik / this.mianownik;
    }
    public Ulamek plus(Ulamek ulamek){
        Ulamek newUlamek =  new Ulamek((this.licznik * ulamek.getMianownik()) + (ulamek.getLicznik() * this.mianownik), this.mianownik * ulamek.getMianownik());
        newUlamek.skroc();
        return newUlamek;
    }
    public Ulamek minus(Ulamek ulamek){
        Ulamek newUlamek = new Ulamek((this.licznik * ulamek.getMianownik()) - (ulamek.getLicznik() * this.mianownik), this.mianownik * ulamek.getMianownik());
        newUlamek.skroc();
        return newUlamek;
    }
    public Ulamek razy(Ulamek ulamek){
        Ulamek newUlamek = new Ulamek(this.licznik * ulamek.licznik, this.mianownik * ulamek.mianownik);
        newUlamek.skroc();
        return newUlamek;
    }
    public void odwroc(){
        int licz = this.licznik;
        this.licznik = this.mianownik;
        this.mianownik = licz;
    }
    public void skroc(){
        int min = 0;
        if(this.licznik < this.mianownik) min = this.licznik;
        else min = this.mianownik;
        int dzielnik = 1;
        for(int i = min; i > 1; i--){
            if(this.licznik % i == 0 && this.mianownik % i == 0){
                dzielnik = i;
            }
        }
        this.licznik /= dzielnik;
        this.mianownik /= dzielnik;
    }

    @Override
    public String toString() {
        return this.licznik+"/"+this.mianownik;
    }
}
