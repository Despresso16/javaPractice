import java.math.BigInteger;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println("Zad1");
        Ulamek obj, obj2;
        Ulamek ul = new Ulamek(6, 9);
        System.out.println(ul.getLicznik() + " | " + ul.getMianownik());
        ul.skroc();
        System.out.println(ul.getLicznik() + " | " + ul.getMianownik());

        obj = new Ulamek(6,8);

        obj2 = new Ulamek(3,7);

        System.out.println(obj);

        double x = obj.rozwDziesietne();

        Ulamek obj3 = obj.plus(obj2);

        Ulamek obj4 = obj.minus(obj2);

        Ulamek obj5 = obj.razy(obj2);
        System.out.println(obj.toString() + ", " + obj2.toString() + ", " + obj3.toString() + ", " + obj4.toString() + ", " + obj5.toString());

        obj.odwroc();
        obj.skroc();
        System.out.println("Zad2");
        Wektor w1 = new Wektor(2, 2);
        Wektor w2 = new Wektor(2, 2);
        Wektor w3 = w1.dodajWektory(w2);
        System.out.println(w3.iloczynWektorowy(w2));
        System.out.println(w2.iloczynSkalarny(w1));
        System.out.println("Zad3");
        BigInteger bigInteger = new BigInteger(33, new Random());
        BigLiczba bl = new BigLiczba(bigInteger);
        System.out.println(bl.getWartosc());
        System.out.println(bl.isDividedBy(new BigInteger(44, new Random())));
        System.out.println(bl.isPrimeNumber());
        
    }
}