public class Wektor {
    private double przesunX;
    private double przesunY;

    public Wektor(double przesunX, double przesunY) {
        this.przesunX = przesunX;
        this.przesunY = przesunY;
    }

    public double getPrzesunX() {
        return przesunX;
    }

    public void setPrzesunX(double przesunX) {
        this.przesunX = przesunX;
    }

    public double getPrzesunY() {
        return przesunY;
    }

    public void setPrzesunY(double przesunY) {
        this.przesunY = przesunY;
    }
    public Wektor dodajWektory(Wektor w){
        return new Wektor(this.przesunX + w.getPrzesunX(), this.przesunY + w.getPrzesunY());
    }
    public double iloczynWektorowy(Wektor w){
        return this.przesunX * w.getPrzesunY() - w.getPrzesunX() * this.przesunY;
    }
    public double iloczynSkalarny(Wektor w){
        return this.przesunX * w.getPrzesunX() + this.przesunY * w.getPrzesunY();
    }
    public Wektor odejmijWektory(Wektor w){
        return new Wektor(this.przesunX - w.getPrzesunX(), this.przesunY - w.getPrzesunY());
    }

}
